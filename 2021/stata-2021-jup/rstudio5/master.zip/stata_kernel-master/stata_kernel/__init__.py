"""An example Jupyter kernel"""

__version__ = '1.12.3'
