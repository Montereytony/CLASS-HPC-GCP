# Jupyter Console

To use it as a console, in your terminal or command prompt run:
```
jupyter console --kernel stata
```

Example:

![Jupyter Notebook](../img/jupyter_console.png)
