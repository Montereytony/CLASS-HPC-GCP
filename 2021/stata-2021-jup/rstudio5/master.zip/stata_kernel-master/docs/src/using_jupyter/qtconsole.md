# Jupyter QtConsole


> The Qt console is a very lightweight application that largely feels like a terminal, but provides a number of enhancements only possible in a GUI, such as inline figures, proper multi-line editing with syntax highlighting, graphical calltips, and much more. The Qt console can use any Jupyter kernel.

Project documentation website:
https://qtconsole.readthedocs.io/en/stable/


![](https://qtconsole.readthedocs.io/en/stable/_images/qtconsole.png)
