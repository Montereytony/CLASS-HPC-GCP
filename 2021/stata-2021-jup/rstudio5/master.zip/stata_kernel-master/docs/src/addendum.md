# Addendum

As an ardent open-source advocate and someone who actively dislikes using Stata,
it somewhat pains me that my work creates value for a proprietary, closed-source
program. I hope that this program improves research in a utilitarian way, and
shows to new users the scope of the open-source tools that have existed for
upwards of a _decade_.

## Contributors

- [Kyle Barron](https://github.com/kylebarron)
- [Mauricio Cáceres](https://github.com/mcaceresb)
- [Full list of contributors](https://github.com/kylebarron/stata_kernel/graphs/contributors)
